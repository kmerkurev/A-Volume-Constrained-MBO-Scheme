#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "vlfeat/vl/kdtree.h"
#include <math.h>


typedef struct{
    int index;
    float dist;
}indexedFloat;

static void *get_file_data(const char *fileName){
    
    FILE *f=fopen(fileName,"r");
    size_t fsize;
    fseek(f,0L,SEEK_END);
    fsize=ftell(f);
    fseek(f,0L,SEEK_SET);
    void *data=malloc(fsize);
    fread(data,1,fsize,f);
    fclose(f);
    return data;
}


static void overwrite_data_to_file(void *data, const char *fileName, size_t numBytes){
    FILE *f=fopen(fileName,"w");
    fwrite(data,1,numBytes,f);
    fclose(f);
}



int compare_indexed_floats(const void *p, const void *q){
    
    indexedFloat f1=*((indexedFloat *) p);
    indexedFloat f2=*((indexedFloat *) q);
    
    if(f2.dist>f1.dist){
        return -1;
    }else if(f1.dist>f2.dist){
        return 1;
    }else{
        return 0;
    }
    
}

void sort_indexed_floats(indexedFloat *distances, int num){
    
    qsort(distances, num, sizeof(indexedFloat), &compare_indexed_floats);
    
}





int main(int argc, char *argv[]){
    
    //number of nearest neighbors to compute
    int numNeighbors=atoi(argv[1]);
    //number of comparisons VLFeat will use when computing nearest neighbors.  More comparisons means higher accuracy but longer computation time. For MNIST anything above 300 gives reasonable results.
    int numComparisons=atoi(argv[2]);
    
    //dimension of feature vector
    int fullDim=784;
    int i,j;
    clock_t b,e;
    b=clock();
    
    int numTrees=1;
    
    //total number of vectors
    int total=70000;
    
   //read data (containing numerical feature vectors for each element)
    unsigned char *cdata=get_file_data("combined_test_and_training_images");
    
    float *data=calloc(total*fullDim,sizeof(float));
    //used by vlfeat to store nearest neighbor indicies
    vl_uint32 *indicies=calloc(total*numNeighbors,sizeof(vl_uint32));
    
    //used by vlfeat to store nearest neighbor distances
    float *distances=calloc(total*numNeighbors,sizeof(float));
    
    //convert images to float representation
    for(i=0;i<total;i++){
        for(j=0;j<fullDim;j++){
            data[i*fullDim+j]=cdata[i*fullDim+j]/255.0;
        }
    }
    
   
    
    // vlfeat initialization
    vl_size numN=numNeighbors;
    vl_size tot=total;
    VlKDForest *forest= vl_kdforest_new(VL_TYPE_FLOAT,fullDim,numTrees,VlDistanceL2);
    vl_kdforest_build(forest,total,data);
    vl_kdforest_set_max_num_comparisons(forest,numComparisons);
    
    //compute nearest neighbors
    vl_kdforest_query_with_array(forest,indicies, numN, tot,distances,data);
    
    
    //convert index and distance data into one struct, could also save indicies and distances separately.
    indexedFloat *result=calloc(total*numNeighbors,sizeof(indexedFloat));
    for(i=0;i<total;i++){
        for(j=0;j<numNeighbors;j++){
            result[i*numNeighbors+j].index=indicies[i*numNeighbors+j];
            result[i*numNeighbors+j].dist=distances[i*numNeighbors+j];
        }
    }
    //save result as an indexedFloat
    overwrite_data_to_file(result,"vl_neighbor_data_mnist",total*numNeighbors*sizeof(indexedFloat));
    
    //cleanup
    free(result);
    free(data);
    free(indicies);
    free(distances);
    vl_kdforest_delete(forest);
    
    e=clock();
    
    printf("%f\n", (e-b)/(CLOCKS_PER_SEC*1.0));
    
    
    
}















